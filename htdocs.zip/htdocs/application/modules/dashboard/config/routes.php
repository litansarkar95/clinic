<?php  if(!defined("BASEPATH")) exit("No direct script access allowed");

$route["auth"] = "dashboard/auth"; 
$route["logout"] = "dashboard/auth/logout"; 



<?php  if(!defined("BASEPATH")) exit("No direct script access allowed");

$route["purchase"] = "purchase/index"; 

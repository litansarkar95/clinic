<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('patient_model');
    }

    public function savegromdialog() {
        $data = array(
            'pat_name'      => $this->input->post('pat_name'),
            'pat_address'   => $this->input->post('pat_address'),
            'pat_mobile'    => $this->input->post('pat_mobile'),
            'pat_sex'       => $this->input->post('pat_sex'),
            'pat_age'       => $this->input->post('pat_age'),
            'pat_age_type'  => $this->input->post('pat_age_type')
        );

        $insert_id = $this->patient_model->save_patient($data);
        $data['pat_id'] = $insert_id;

        echo json_encode($data);
    }

    public function SearchPatients() {
        $term = $this->input->get('term');
        $result = $this->patient_model->search_patients($term);

        $response = array();
        foreach ($result as $row) {
            $response[] = array(
                'label' => $row['pat_name'] . ' - ' . $row['pat_mobile'],
                'value' => $row['pat_name'],
                'address' => $row['pat_address'],
                'pat_mobile' => $row['pat_mobile'],
                'sex' => $row['pat_sex'],
                'age' => $row['pat_age'],
                'age_type' => $row['pat_age_type'],
                'pat_id' => $row['pat_id']
            );
        }

        echo json_encode($response);
    }

    public function getPatientData() {
        $pat_id = $this->input->post('pat_id');
        $data = $this->patient_model->get_patient_by_id($pat_id);
        echo json_encode($data);
    }


    public function drsave() {
        $data = array(
            'name'          => $this->input->post('dr_name'),
            'degree'        => $this->input->post('dr_degree'),
            'is_active'     => 1,
        );

        $insert_id = $this->patient_model->save_doctor($data);
        $data['dr_id'] = $insert_id;

        echo json_encode($data);
    }


    public function searchDoctor() {
        $term = $this->input->get('term');
        $result = $this->patient_model->search_doctors($term);

        $response = array();
        foreach ($result as $row) {
            $response[] = array(
                'label' => $row['name'] . ' - ' . $row['degree'],
                'value' => $row['name'],
                'id' => $row['id'],
                'degree' => $row['degree']
            );
        }

        echo json_encode($response);
    }
}

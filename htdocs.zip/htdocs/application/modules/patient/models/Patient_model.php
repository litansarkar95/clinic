<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patient_model extends CI_Model {

    public function save_patient($data) {
        $this->db->insert('patients', $data);
        return $this->db->insert_id(); // returns new patient ID
    }
    
    public function save_doctor($data) {
        $this->db->insert('doctor', $data);
        return $this->db->insert_id(); // returns new doctor ID
    }
    public function search_patients($term) {
        $this->db->like('pat_name', $term);
        $this->db->or_like('pat_mobile', $term);
        return $this->db->get('patients')->result_array();
    }

    public function get_patient_by_id($pat_id) {
        $this->db->where('pat_id', $pat_id);
        return $this->db->get('patients')->row_array();
    }
    public function search_doctors($term) {
        $this->db->like('name', $term);
       // $this->db->or_like('pat_mobile', $term);
        return $this->db->get('doctor')->result_array();
    }
}
